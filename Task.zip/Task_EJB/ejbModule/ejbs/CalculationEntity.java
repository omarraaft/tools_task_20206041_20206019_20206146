package ejbs;

import javax.ejb.Stateless;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Stateless
@Entity
public class CalculationEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int CalculationID;
	public int number1;
	public int number2;
	public String operation;
}
