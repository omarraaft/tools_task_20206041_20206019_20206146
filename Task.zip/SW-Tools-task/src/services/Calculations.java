package services;

import java.util.List;

import javax.annotation.security.PermitAll;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import ejb.CalculationEntity;
import ejb.Calculator;

@Stateless
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
@Path("/api")
@PermitAll
public class Calculations {
	@PersistenceContext (unitName = "hello")
	EntityManager EM;
	@EJB
	Calculator C = new Calculator();
	@POST
	@Path("/calc")
	public int calculate(CalculationEntity CE) {
		EM.persist(CE);
		return C.calculate(CE);
	}
	@GET
	@Path("/test")
	public String test() {
		return "Working successfully";
	}
	@GET
	@Path("/calculations")
	public List<CalculationEntity> getAllCalculations() {
		return EM.createQuery("select c from CalculationEntity c", CalculationEntity.class).getResultList();
	}
}
