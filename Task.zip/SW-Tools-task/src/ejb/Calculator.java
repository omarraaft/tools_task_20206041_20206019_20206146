package ejb;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

@Stateless
@LocalBean
public class Calculator {
	public int calculate(CalculationEntity CE) {
		if(CE.operation.equals("+")) {
			return CE.number1+CE.number2;
		}
		else if(CE.operation.equals("-")) {
			return CE.number1-CE.number2;
		}
		else if(CE.operation.equals("*")) {
			return CE.number1*CE.number2;
		}
		else {
			return CE.number1/CE.number2;
		}
	}
}
